# === Challenge 1: Collatz Conjecture ===
print("=== Challenge 1: Collatz Conjecture ===")
num = int(input("Enter starting number: "))
print("Sequence:")

steps = 0
while num != 1:
    print(num, end=" ")
    if num % 2 == 0:
        num //= 2
    else:
        num = 3 * num + 1
    steps += 1
print(1)  # Final 1 in the sequence
print("\nSteps:", steps)

# === Challenge 2: Prime Number Checker ===
print("\n=== Challenge 2: Prime Number Checker ===")
n = int(input("Enter a number: "))

print(f"Testing divisors from 2 to {n-1}...")
is_prime = True
for i in range(2, n):
    if n % i == 0:
        is_prime = False
        break

if is_prime:
    print(f"{n} is prime!")
else:
    print(f"{n} is not prime.")

# === Challenge 3: Multiplication Table ===
print("\n=== Challenge 3: Multiplication Table ===")
print("Multiplication Table:")

# Print header row
print("     ", end="")
for i in range(1, 11):
    print(f"{i:4}", end="")
print()

# Print table rows
for i in range(1, 11):
    print(f"{i:2}", end="  ")
    for j in range(1, 11):
        print(f"{i*j:4}", end="")
    print()

